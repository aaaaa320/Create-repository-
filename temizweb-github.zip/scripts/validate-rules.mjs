import { readFile } from "node:fs/promises";

const rules = JSON.parse(await readFile(new URL("../rules/ads.json", import.meta.url), "utf8"));
const allowedTypes = new Set([
  "main_frame", "sub_frame", "stylesheet", "script", "image", "font",
  "object", "xmlhttprequest", "ping", "csp_report", "media", "websocket", "other"
]);

if (!Array.isArray(rules) || rules.length === 0) {
  throw new Error("Kural dosyası boş veya dizi biçiminde değil.");
}
if (rules.length > 30_000) {
  throw new Error("Tek statik kural kümesi 30.000 kural sınırını aşıyor.");
}

const ids = new Set();
for (const rule of rules) {
  if (!Number.isInteger(rule.id) || rule.id < 1 || ids.has(rule.id)) {
    throw new Error(`Geçersiz veya yinelenen kural kimliği: ${rule.id}`);
  }
  ids.add(rule.id);

  if (rule.action?.type !== "block") {
    throw new Error(`Kural ${rule.id}: beklenen eylem "block".`);
  }
  if (typeof rule.condition?.urlFilter !== "string" || !rule.condition.urlFilter.startsWith("||")) {
    throw new Error(`Kural ${rule.id}: geçersiz alan adı filtresi.`);
  }
  if (!Array.isArray(rule.condition.resourceTypes) || rule.condition.resourceTypes.length === 0) {
    throw new Error(`Kural ${rule.id}: resourceTypes gerekli.`);
  }
  for (const type of rule.condition.resourceTypes) {
    if (!allowedTypes.has(type)) throw new Error(`Kural ${rule.id}: bilinmeyen resourceType "${type}".`);
  }
}

console.log(`OK — ${rules.length} kural doğrulandı; kimlikler benzersiz ve kaynak türleri geçerli.`);

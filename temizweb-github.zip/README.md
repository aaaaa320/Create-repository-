# TemizWeb — Hafif Reklam Filtresi

TemizWeb, Chromium tabanlı tarayıcılar için hazırlanmış, Manifest V3 kullanan küçük bir reklam engelleyici prototipidir. Seçili üçüncü taraf reklam ağı alan adlarına yapılan istekleri tarayıcının yerleşik `declarativeNetRequest` API'siyle durdurur.

## Özellikler

- Araç çubuğu penceresinden tek tıkla açma/kapatma
- Başlangıç listesinde 24 reklam ağı alan adı
- İstekleri içerik kodu çalıştırmadan tarayıcı düzeyinde filtreleme
- Sunucu, telemetri veya harici kütüphane yok
- Tarama geçmişi tutulmaz; yerel depolamada yalnızca açık/kapalı tercihi saklanır

## Kurulum

1. Bu depoyu indirin veya klonlayın.
2. Chrome'da `chrome://extensions` sayfasını açın. Brave veya Edge'de ilgili uzantılar sayfasını açın.
3. **Geliştirici modu**nu etkinleştirin.
4. **Paketlenmemiş öğe yükle** seçeneğine basıp bu klasörü seçin.
5. TemizWeb simgesini araç çubuğuna sabitleyip durumunu açın.

Bu ilk sürüm Chromium tabanlı tarayıcılar için hedeflenmiştir; Firefox'ta test edilmemiştir.

## Kuralları doğrulama

Node.js yüklüyse proje kökünde çalıştırın:

```bash
node scripts/validate-rules.mjs
```

## Kapsam ve sınırlamalar

Bu, küçük bir başlangıç listesidir; kapsamlı filtre listelerinin veya uBlock Origin gibi olgun engelleyicilerin yerine geçmez. Yalnızca listelenen alan adlarına yapılan seçili istekleri engeller. Birinci taraf reklamları, reklam içeriğini kendi alan adından sunan siteleri ve listede bulunmayan yeni alan adlarını kaçırabilir. Bazı reklam ağları meşru içerik isteklerinde de kullanılabildiğinden, bir sayfa bozulursa TemizWeb'i kapatıp tekrar deneyin.

Kurallar bilerek alan adı tabanlı ve denetlenebilir tutuldu. Yeni kural eklerken alan adının reklam sunumu amacıyla kullanıldığını doğrulayın ve olası yanlış pozitifleri açıklayın.

## Gizlilik

Uzantı sayfa içeriğini okumaz, gezinme geçmişini kaydetmez ve hiçbir yere veri göndermez. Filtreleme tarayıcının yerleşik istek-kural API'siyle yerel olarak yapılır.

## Lisans

MIT — ayrıntılar için [`LICENSE`](LICENSE) dosyasına bakın.

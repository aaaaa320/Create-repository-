const statusBadge = document.querySelector("#status");
const statusCopy = document.querySelector("#status-copy");
const toggleButton = document.querySelector("#toggle");
const errorMessage = document.querySelector("#error");
const ruleCount = document.querySelector("#rule-count");

function render(enabled) {
  statusBadge.textContent = enabled ? "Açık" : "Kapalı";
  statusBadge.className = `status ${enabled ? "on" : "off"}`;
  statusCopy.textContent = enabled
    ? "Seçili reklam ağlarına giden istekler engelleniyor."
    : "Reklam filtresi şu anda devre dışı.";
  toggleButton.textContent = enabled ? "Filtreyi kapat" : "Filtreyi aç";
  toggleButton.className = enabled ? "" : "off";
  toggleButton.setAttribute("aria-pressed", String(enabled));
  toggleButton.disabled = false;
}

function showError(message) {
  errorMessage.textContent = message;
  errorMessage.hidden = false;
}

toggleButton.addEventListener("click", async () => {
  toggleButton.disabled = true;
  errorMessage.hidden = true;
  const currentlyEnabled = toggleButton.getAttribute("aria-pressed") === "true";
  try {
    const response = await chrome.runtime.sendMessage({
      type: "set-status",
      enabled: !currentlyEnabled
    });
    if (!response?.ok) throw new Error(response?.error || "Ayar kaydedilemedi.");
    render(response.enabled);
  } catch (_error) {
    showError("Ayar değiştirilemedi. Uzantıyı yeniden yükleyip tekrar deneyin.");
    toggleButton.disabled = false;
  }
});

chrome.runtime.sendMessage({ type: "get-status" })
  .then((response) => {
    if (!response?.ok) throw new Error(response?.error || "Durum okunamadı.");
    render(response.enabled);
  })
  .catch(() => {
    statusBadge.textContent = "Hata";
    statusCopy.textContent = "Uzantı durumu okunamadı.";
    showError("Uzantıyı chrome://extensions sayfasından yeniden yüklemeyi deneyin.");
    toggleButton.disabled = true;
  });

fetch(chrome.runtime.getURL("rules/ads.json"))
  .then((response) => response.json())
  .then((rules) => {
    ruleCount.textContent = `${rules.length} reklam ağı kuralı`;
  })
  .catch(() => {
    ruleCount.textContent = "Kural listesi okunamadı";
  });

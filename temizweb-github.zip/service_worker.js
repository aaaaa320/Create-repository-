const RULESET_ID = "ad_domains";

async function setFilteringEnabled(enabled) {
  await chrome.declarativeNetRequest.updateEnabledRulesets({
    enableRulesetIds: enabled ? [RULESET_ID] : [],
    disableRulesetIds: enabled ? [] : [RULESET_ID]
  });
  await chrome.storage.local.set({ enabled });
}

async function restoreFilteringState() {
  const { enabled } = await chrome.storage.local.get({ enabled: true });
  await setFilteringEnabled(enabled !== false);
}

chrome.runtime.onInstalled.addListener(() => {
  void restoreFilteringState();
});

chrome.runtime.onStartup.addListener(() => {
  void restoreFilteringState();
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "get-status") {
    chrome.storage.local
      .get({ enabled: true })
      .then(({ enabled }) => sendResponse({ ok: true, enabled: enabled !== false }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "set-status" && typeof message.enabled === "boolean") {
    setFilteringEnabled(message.enabled)
      .then(() => sendResponse({ ok: true, enabled: message.enabled }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  return false;
});
